#ifndef IRSENSOR_H
#define IRSENSOR_H

#include <Arduino.h>
#define L1_IR 23 // Left IR sensor
#define R1_IR 34  // Right IR sensor

class irSensor
{
private:
    const uint8_t _leftIRPin = L1_IR;
    const uint8_t _rightIRPin = R1_IR;

    int readLeft();
    int readRight();
public:
    void irsensorInit();
    void readIR();
    void trackForward();
    void trackBackward();
    void turnLeftIR();
    void turnRightIR();
};
#endif
