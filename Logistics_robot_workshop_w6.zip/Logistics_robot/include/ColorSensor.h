#ifndef COLOR_SENSOR_H
#define COLOR_SENSOR_H

#include <Arduino.h>
#include <Adafruit_TCS34725.h>
class NARC;

class ColorSensor
{
private:
    bool _commonAnode;
    byte _gammaTable[256];
    Adafruit_TCS34725 _tcs;
    uint8_t _red, _green, _blue;

    void _generateGammaTable();
public:
    ColorSensor(bool commmonAnode = false);
    void colorsensorInit();
    void readColor();
    void detectColor(NARC& mqtt);

    uint8_t getRed() const;
    uint8_t getGreen() const;
    uint8_t getBlue() const;

};



#endif