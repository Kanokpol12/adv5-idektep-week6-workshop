#ifndef MOTOR_H
#define MOTOR_H

#include <Arduino.h>

class Motor
{
private:
    /* data */
public:
  void motorInit();
  static void forward(int d);
  static void backward(int d);
  static void turn_left(int d);
  static void turn_right(int d);
  static void stop(int d);
  void moveup();
  void movedown();

};
#endif