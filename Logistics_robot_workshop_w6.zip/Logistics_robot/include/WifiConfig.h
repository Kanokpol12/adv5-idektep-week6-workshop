#ifndef WIFI_CONFIG_H
#define WIFI_CONFIG_H

#include <Arduino.h>
#include <WiFiManager.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <FS.h>
#include <SPIFFS.h>
#include <ArduinoJson.h>

#define RESET_BUTTON 17
#define BUZZER_PIN 18

class WifiConfig
{

public:
  public:
    void initWiFi();
    void BuzzerTrigger(int times, int delayMs);
    const char* getMQTTBroker();
    int getMQTTPort();
    const char* getClientID();
    const char* getTopicName();

  private:
    int times;
    int delayMs;
    void saveConfig();
    void loadConfig();
};
#endif
