# main.py
import time, vars
from decorators import logger, timeit_log
from utils import message_handle
from module.mqtt_module import connect_mqtt, on_publish, MQTT_TOPIC

# ไม่ต้อง import serial_module หรือ parse_data แล้ว เพราะเรานับจำนวนข้อความอย่างเดียว

def adv_control(client):
    # ตัวแปรสำหรับป้องกันการส่งคำสั่งซ้ำ
    sent_go = False
    sent_go2 = False
    
    try:
        message_handle(client=client, topic=MQTT_TOPIC["RST_TOPIC"], msg="RESET SYSTEM")
        message_handle(client=client, topic=MQTT_TOPIC["UI_TOPIC"], msg="WAITING DATA FROM AGV via MQTT...")
        
        while True:
            # เช็คจำนวนข้อความในคิวที่ส่งมาจาก AGV
            msg_count = len(vars.sub_msg)
            
            # --- จังหวะที่ 1: รับสีครบ 2 ครั้ง ➡️ ส่ง "go" ---
            if msg_count == 2 and not sent_go:
                logger.info(f"Received 2 colors: {vars.sub_msg[0]}, {vars.sub_msg[1]}")
                message_handle(client=client, topic=MQTT_TOPIC["UI_TOPIC"], msg="[PYTHON]: RECEIVED 2 COLORS -> SENDING 'go'")
                
                # ส่งคำสั่ง go ให้ AGV
                msg = client.publish(MQTT_TOPIC["CONTROL_TOPIC"], "go")     
                on_publish(msg, MQTT_TOPIC["CONTROL_TOPIC"], "go")
                
                # ล็อกสถานะไว้ว่าส่ง go ไปแล้ว จะได้ไม่ส่งซ้ำ
                sent_go = True

            # --- จังหวะที่ 2: รับสีเพิ่มอีก 1 ครั้ง (รวมเป็น 3) ➡️ ส่ง "go2" ---
            elif msg_count >= 3 and not sent_go2:
                logger.info(f"Received 3rd color: {vars.sub_msg[2]}")
                message_handle(client=client, topic=MQTT_TOPIC["UI_TOPIC"], msg="[PYTHON]: RECEIVED 3 COLORS -> SENDING 'go2'")
                
                # ส่งคำสั่ง go2 ให้ AGV
                msg = client.publish(MQTT_TOPIC["CONTROL_TOPIC"], "go2")   
                on_publish(msg, MQTT_TOPIC["CONTROL_TOPIC"], "go2")
                
                # ล็อกสถานะ
                sent_go2 = True
                
                # --- จบกระบวนการ: เคลียร์คิวเพื่อเริ่มรอบใหม่ ---
                time.sleep(1) # หน่วงเวลาเล็กน้อยให้ส่งข้อความเสร็จ
                vars.sub_msg.clear() # ล้างข้อความทั้ง 3 อันทิ้ง
                sent_go = False      # ปลดล็อกสถานะ
                sent_go2 = False     # ปลดล็อกสถานะ
                
                message_handle(client=client, topic=MQTT_TOPIC["UI_TOPIC"], msg="COMPLETE PROCESS. WAITING FOR NEW ROUND...")

            # หน่วงเวลาลูปสั้นๆ เพื่อไม่ให้ CPU ทำงานหนักเกินไป
            time.sleep(0.1)
                
    except Exception as e:
        logger.error(f"Main function error : {e}")
    except KeyboardInterrupt:
        logger.warning("Stopped by user.")

def run():
    client = connect_mqtt()
    client.subscribe(MQTT_TOPIC["COLOR_TOPIC"])
    client.loop_start() # ให้ MQTT รันแบบ Background
    adv_control(client=client)

if __name__ == '__main__':
    run()