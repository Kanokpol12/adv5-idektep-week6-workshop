from paho.mqtt import client as mqtt_client
import random
import vars
from decorators import logger, timeit_log

MQTT_CONNECT = {
    "BROKER" : 'broker.emqx.io',
    "PORT"   : 1883,
    "CLIENT_ID" : f'idt_adv-{random.randint(0,100)}'
}

MQTT_TOPIC = {                          
    "CONTROL_TOPIC" :  'name/adv/seq',          # edit topic here
    "COLOR_TOPIC" :  'name/adv/cos',            # edit topic here
    "UI_TOPIC" : 'name/adv/ui',
    "COOR_TOPIC": 'name/adv/coor',
    "SHAPE_TOPIC": 'name/adv/shp',
    "COL_TOPIC": 'name/adv/col',
    "OBS_TOPIC": 'name/adv/obs',
    "RST_TOPIC": 'name/adv/rst'
}

def connect_mqtt():
    client = mqtt_client.Client(mqtt_client.CallbackAPIVersion.VERSION1, MQTT_CONNECT["CLIENT_ID"])
    client.on_connect = lambda client, userdata, flags, rc: logger.info("CONNECTED TO MQTT BROKER!") if rc ==0 else logger.error("FAILED TO CONNECT")
    client.on_message = on_message 
    client.connect(MQTT_CONNECT["BROKER"], MQTT_CONNECT["PORT"], 120)
    return client

def on_message(client, userdata, msg):
    payload = msg.payload.decode('utf-8')
    
    # พิมพ์ Log ทุกข้อความที่รับมาได้ เพื่อให้เราเห็นว่าบอร์ดส่งอะไรมาบ้าง
    logger.info(f"received '{payload}' from '{msg.topic}'")
    
    # กรองเอาเฉพาะข้อความที่มีคำว่า "Detect" ถึงจะเก็บลง List (ข้าม ESP32 connected ไป)
    if "Detect" in payload:
        vars.sub_msg.append(payload)
    
def on_publish(result, topic, msg):
    status = result[0]
    if status == 0:
        logger.info(f"Published: '{msg}' to topic '{topic}'")
    else:
        logger.error(f"Failed to send message to topic {topic}")