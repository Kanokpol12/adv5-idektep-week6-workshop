import serial, time
from decorators import logger, timeit_log
from utils import message_handle

def init_serial(port):
    return serial.Serial(port=port, baudrate=115200)

def send_state(serial_port, data):
    try:
        if not serial_port or not serial_port.is_open:
            raise serial.SerialException("Port not open")
        serial_port.write(f"{data}".encode('utf-8'))
        time.sleep(0.5)
        logger.info(f"Sent: {data}")
    except serial.SerialException as e:
        logger.error(f"Error sending data: {e}")
        
def receive_state(serial_port):
    # ลบ state_message ของ Cartesian ออกให้หมด เหลือแค่ Conveyor
    state_message = {                             
        "command: Conveyor ON" : 'conveyor-ON',
        "command: Conveyor OFF": 'conveyor-OFF',
        "auto: Conveyor OFF": 'conveyor-detect',
        "Sensor&Motor Init" : 'conveyor-setup'
    }
    try:
        while True:
            if serial_port.in_waiting > 0:
                line = serial_port.readline().decode('utf-8').rstrip()
                logger.info(f"Receive: {line}")
                if line in state_message:
                    return state_message[line]
    except serial.SerialException as e:
        logger.error(f"Serial communication error; {e}")
    except KeyboardInterrupt:
        logger.warning("Stopped by user.")
    finally:
        pass

# ตัด cart_port ออกจาก parameter
def process_setup(client, conv_port: str, topic):
    try:
        ser_conv = init_serial(port=conv_port)
        if ser_conv.is_open:
            logger.info("SERIAL PORT IS OPEN AND CONFIGURED.")
            
            # Setup เฉพาะ Conveyor
            receive_state(serial_port=ser_conv)
            time.sleep(0.1)
            send_state(serial_port=ser_conv,data="conveyor off")
            receive_state(serial_port=ser_conv)
            message_handle(client=client, topic=topic, msg="[CONVEYOR]:SETUP COMPLETE!")
            
            # --- [ตัดโค้ด Setup ของ Cartesian ออก] ---
            
            # ส่งคืนแค่ตัวเดียว
            return ser_conv
            
    except serial.SerialException as e:
        logger.error(f"Serial communication error: {e}")
    return None