# v4l2-ctl --list-devices
# x:113.82 y:67.36
import cv2, time
import numpy as np
from decorators import logger, timeit_log
from utils import message_handle

def object_position_check(data_stream, stamp_choose, target_count=40, cam_x_offset=56, cam_y_offset=48):
    count, last_value = 0, None
    for data in data_stream:
        if data == last_value:
            count += 1
        else:
            count = 1 
            last_value = data
        if count == target_count:
            logger.info(data)
            return f"G{stamp_choose} X{data[0]+cam_x_offset:.1f} Y{data[1]+cam_y_offset:.1f}"
        
def object_position_cal(frame, cx, cy, mm_per_pixel =0.394):
    h, w, _ = frame.shape
    cam_center = (int(w/2), int(h/2))
    offset_x = cx - cam_center[0]
    offset_y = cy - cam_center[1]
    cv2.circle(frame, (cx, cy), 5, (0,255,0), -1)       
    cv2.circle(frame, cam_center, 5, (255,0,0), -1)
    cv2.line(frame, cam_center, (cx,cy), (255,255,255), 2)
    return int(offset_x*mm_per_pixel), int(offset_y*mm_per_pixel)


def color_detection_choose(c_choose, frame):
    frame_hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    ranges = {
        # "red": [(np.array([0, 100, 100]), np.array([10, 255, 255])),
        #         (np.array([160, 100, 100]), np.array([179, 255, 255]))],
        "blue": [(np.array([94.31, 100.08, 135.72]), np.array([120.29, 255, 255]))],
        "yellow": [(np.array([28.87, 109.68, 131.6129]), np.array([51.97, 255, 255]))],
        "orange": [(np.array([0, 76.77, 215.24]), np.array([28, 255, 255]))],
        "green": [(np.array([42.344, 91.85, 145.322]), np.array([96.23, 171.37, 255]))]
    }

    if c_choose not in ranges:
        return None

    mask = sum(cv2.inRange(frame_hsv, low, high) for low, high in ranges[c_choose])
    return mask
    
def shape_detection_case(approx):
    if len(approx) == 3:
        return "Triangle"
    elif len(approx) == 4:
        return "Rectangle"
    # elif len(approx) == 5:
    #     return "Pentagon"
    # elif len(approx) == 6:
    #     return "Hexagon"
    else:
        return "Circle"

def camera_preview_display(stop_event, device_num: int):
    cap = cv2.VideoCapture(device_num)
    try:
        logger.info("Starting camera preview..")
        while not stop_event.is_set():
            ret, frame = cap.read()
            if not ret:
                logger.error("Failed to read frame.")
                break
            cv2.imshow("OPEN-SHAPE DETECTION", frame)
            if cv2.waitKey(10) & 0xFF == ord("q"):
                logger.warning("Stop camera by user.")
                break
    except Exception as e:
        logger.error(f"Camera display thread error: {e}")
    finally:
        cap.release()
        cv2.destroyAllWindows()

def camera_shape_detection(client , topic ,c_choose: str, stamp_choose: str ,device_num: int):
    cap = cv2.VideoCapture(device_num)
    data_list = []
    font = cv2.FONT_HERSHEY_SIMPLEX
    preview_duration, timeout = 7, 10
    # --- Preview Phase ---
    start_time = time.time()
    while True:
            ret, frame = cap.read()
            if not ret:
                logger.error("Failed to read frame during preview.")
                cap.release()
                cv2.destroyAllWindows()
                return None
            
            elapsed_time = time.time() - start_time
            remaining_time = max(0, int(preview_duration - elapsed_time))
            countdown_message = f"Starting detect in: {remaining_time}s"
            cv2.putText(frame, countdown_message, (300, 450), font, 0.8, (0, 255, 0), 2, cv2.LINE_AA)

            cv2.imshow('OPEN-SHAPE DETECTION', frame)   
            if elapsed_time > preview_duration or cv2.waitKey(10) & 0xFF == ord("q"):
                break

    # --- Detection Phase ---
    message_handle(client=client, topic=topic, msg="[RPI]:SHAPE DETECTION IS PROCESSING")
    detection_start = time.time()
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                logger.error("Failed to read frame from camera.")
                break
            frame = frame[80:250, 150:440]
            mask_c = color_detection_choose(c_choose=c_choose, frame=frame)
            if mask_c is None:
                continue
            contours, _ = cv2.findContours(mask_c, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            if contours:
                detection_start  = time.time()
                c = max(contours, key=cv2.contourArea)
                M = cv2.moments(c)
                peri = cv2.arcLength(c, True)
                approx = cv2.approxPolyDP(c, 0.02*peri, True)
                x, y, w, h = cv2.boundingRect(c)
                cv2.rectangle(frame, (x,y), (x+w, y+h), (0,255,0), 2)

                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                    data = object_position_cal(frame=frame, cx=cx, cy=cy)
                    data_list.append(data)  
                    data_list = data_list[-50:]                
                    offset_x_mm, offset_y_mm = data
                    cv2.putText(frame, f"Offset: ({offset_x_mm:.1f} mm, {offset_y_mm:.1f} mm)", 
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                    shape_detected = shape_detection_case(approx=approx)
                    if shape_detected:
                        cv2.putText(frame, f"shape detect:{shape_detected}", (x + w , y + h + 60),
                                    cv2.FONT_HERSHEY_PLAIN, 0.7, (255, 255, 255), 2)
                        logger.info(f"Shape Detect: '{shape_detected}'")
                    object_result = object_position_check(data_stream=data_list, stamp_choose=stamp_choose)
                    if object_result:
                        return str(object_result), str(shape_detected)
            if time.time() - detection_start > timeout:
                logger.warning("No object detected for 20 seconds. Exiting detection loop.")
                return "home", None
            
            cv2.imshow("OPEN-SHAPE DETECTION", frame)
            if cv2.waitKey(10) == ord('q'):
                logger.info("Closed Camera by user")
                break
        
    except Exception as e:
        logger.error(f"Error during frame processing: {e}")
    finally:
        cap.release()
        cv2.destroyAllWindows()
    