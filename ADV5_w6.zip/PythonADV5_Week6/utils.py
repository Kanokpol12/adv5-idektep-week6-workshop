#util
import time
from decorators import logger, timeit_log
from module.mqtt_module import on_publish

@timeit_log
def parse_data(data):
    if data == "Detect red":
        return "orange", "7"
    if data == "Detect green":
        return "green", "8"
    if data == "Detect blue":
        return "blue", "9"
    else:
        return data

def message_handle(client, topic, msg:str):
    time.sleep(0.1)
    logger.info(f"{msg}")
    mss = client.publish(topic=topic, payload=msg)
    on_publish(mss, topic=topic, msg=msg)
    time.sleep(0.1)